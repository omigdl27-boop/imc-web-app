package com.mycompany.imc.repository;

import com.mycompany.imc.model.Usuario;
import org.springframework.stereotype.Repository;
import java.sql.*;

@Repository
public class UsuarioRepository {
    private static final String DB_URL = "jdbc:sqlite:imc.db";

    public UsuarioRepository() {
        crearTabla();
    }

    private void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS USUARIOS (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre_completo VARCHAR(100) NOT NULL, " +
                "edad INTEGER, " +
                "sexo VARCHAR(10), " +
                "estatura DOUBLE, " +
                "nombre_usuario VARCHAR(50) UNIQUE NOT NULL, " +
                "password VARCHAR(100) NOT NULL)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void guardar(Usuario usuario) {
        String sql = "INSERT INTO USUARIOS (nombre_completo, edad, sexo, estatura, nombre_usuario, password) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, usuario.getNombreCompleto());
            pstmt.setInt(2, usuario.getEdad());
            pstmt.setString(3, usuario.getSexo());
            pstmt.setDouble(4, usuario.getEstatura());
            pstmt.setString(5, usuario.getNombreUsuario());
            pstmt.setString(6, usuario.getPassword());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Usuario buscarPorUsuario(String nombreUsuario) {
        String sql = "SELECT * FROM USUARIOS WHERE nombre_usuario = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreUsuario);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setNombreCompleto(rs.getString("nombre_completo"));
                u.setEdad(rs.getInt("edad"));
                u.setSexo(rs.getString("sexo"));
                u.setEstatura(rs.getDouble("estatura"));
                u.setNombreUsuario(rs.getString("nombre_usuario"));
                u.setPassword(rs.getString("password"));
                return u;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
