package com.mycompany.imc.model;

import java.time.LocalDateTime;

public class HistorialIMC {
    private int id;
    private int idUsuario;
    private double peso;
    private double estatura;
    private double imc;
    private String clasificacion;
    private LocalDateTime fecha;

    public HistorialIMC() {}

    public HistorialIMC(int idUsuario, double peso, double estatura, double imc, String clasificacion) {
        this.idUsuario = idUsuario;
        this.peso = peso;
        this.estatura = estatura;
        this.imc = imc;
        this.clasificacion = clasificacion;
        this.fecha = LocalDateTime.now();
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }

    public double getEstatura() { return estatura; }
    public void setEstatura(double estatura) { this.estatura = estatura; }

    public double getImc() { return imc; }
    public void setImc(double imc) { this.imc = imc; }

    public String getClasificacion() { return clasificacion; }
    public void setClasificacion(String clasificacion) { this.clasificacion = clasificacion; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
}
