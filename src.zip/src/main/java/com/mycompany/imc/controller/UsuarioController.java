package com.mycompany.imc.controller;

import com.mycompany.imc.model.Usuario;
import com.mycompany.imc.service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {
    private final UsuarioService usuarioService = new UsuarioService();

    @GetMapping("/registro")
    public String mostrarRegistro() {
        return "registro";
    }

    @PostMapping("/registro")
    public String registrar(@RequestParam String nombreCompleto,
                            @RequestParam int edad,
                            @RequestParam String sexo,
                            @RequestParam double estatura,
                            @RequestParam String nombreUsuario,
                            @RequestParam String password,
                            Model model) {
        try {
            Usuario usuario = new Usuario(nombreCompleto, edad, sexo, estatura, nombreUsuario, password);
            usuarioService.registrar(usuario);
            return "redirect:/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "registro";
        }
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String nombreUsuario,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        Usuario usuario = usuarioService.login(nombreUsuario, password);
        if (usuario != null) {
            session.setAttribute("usuario", usuario);
            return "redirect:/calcular";
        }
        model.addAttribute("error", "Usuario o contraseña incorrectos");
        return "login";
    }
}
