package com.mycompany.imc.controller;

import com.mycompany.imc.model.HistorialIMC;
import com.mycompany.imc.model.Usuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
public class IMCController {
    private final List<HistorialIMC> historial = new ArrayList<>();

    @GetMapping("/calcular")
    public String mostrarCalcular(HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }
        return "calcular";
    }

    @PostMapping("/calcular")
    public String calcular(@RequestParam double peso, HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }
        if (peso <= 0) {
            model.addAttribute("error", "El peso debe ser mayor a 0");
            return "calcular";
        }
        double imc = peso / (usuario.getEstatura() * usuario.getEstatura());
        String clasificacion = clasificarIMC(imc);
        HistorialIMC registro = new HistorialIMC(usuario.getId(), peso, usuario.getEstatura(), imc, clasificacion);
        historial.add(registro);
        model.addAttribute("imc", String.format("%.2f", imc));
        model.addAttribute("clasificacion", clasificacion);
        return "calcular";
    }

    private String clasificarIMC(double imc) {
        if (imc < 18.5) return "Bajo peso";
        else if (imc < 25) return "Normal";
        else if (imc < 30) return "Sobrepeso";
        else return "Obesidad";
    }
}
