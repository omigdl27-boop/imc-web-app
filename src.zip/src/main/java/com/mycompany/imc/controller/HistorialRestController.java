package com.mycompany.imc.controller;

import com.mycompany.imc.model.HistorialIMC;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/historial")
public class HistorialRestController {
    private final List<HistorialIMC> historial = new ArrayList<>();

    @GetMapping
    public List<HistorialIMC> obtenerHistorial() {
        return historial;
    }

    @PostMapping
    public HistorialIMC agregar(@RequestBody HistorialIMC registro) {
        historial.add(registro);
        return registro;
    }
}
