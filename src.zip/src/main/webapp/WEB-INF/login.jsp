<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Iniciar Sesión</h2>
    <form action="login" method="post">
        Usuario: <input type="text" name="nombreUsuario" required><br><br>
        Contraseña: <input type="password" name="password" required><br><br>
        <input type="submit" value="Entrar">
    </form>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
    <p>¿No tienes cuenta? <a href="registro">Regístrate</a></p>
</body>
</html>
