<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="com.mycompany.imc.model.Usuario" %>
<!DOCTYPE html>
<html>
<head>
    <title>Calcular IMC</title>
</head>
<body>
    <% Usuario usuario = (Usuario) session.getAttribute("usuario"); %>
    <h2>Hola, <%= usuario.getNombreCompleto() %></h2>
    <form action="calcular" method="post">
        Peso (kg): <input type="number" step="0.1" name="peso" required><br><br>
        <input type="submit" value="Calcular IMC">
    </form>
    <% if (request.getAttribute("imc") != null) { %>
        <h3>Tu IMC es: <%= request.getAttribute("imc") %></h3>
        <p>Clasificación: <%= request.getAttribute("clasificacion") %></p>
    <% } %>
</body>
</html>
