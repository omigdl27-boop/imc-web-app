
<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
</head>
<body>
    <h2>Registro de Usuario</h2>
    <form action="registro" method="post">
        Nombre completo: <input type="text" name="nombreCompleto" required><br><br>
        Edad: <input type="number" name="edad" required><br><br>
        Sexo: <select name="sexo">
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
        </select><br><br>
        Estatura (m): <input type="number" step="0.01" name="estatura" required><br><br>
        Usuario: <input type="text" name="nombreUsuario" required><br><br>
        Contraseña: <input type="password" name="password" required><br><br>
        <input type="submit" value="Registrar">
    </form>
    <% if (request.getAttribute("error") != null) { %>
        <p style="color:red;"><%= request.getAttribute("error") %></p>
    <% } %>
</body>
</html>